


                  ----- SQL Project: Education System_Nu (National University) --------
                       ---- Project By: MAKSUDUR RAHMAN  -------
                      -- Batch ID: ESAD-CS/PNTL-M/45/01 -------
                            -- Trainee ID: 1266309




USE EducationSystem_Nu
GO

-- INSERT DATA TO Department TABLE

INSERT INTO Department VALUES('Bngla')
INSERT INTO Department VALUES('English')
INSERT INTO Department VALUES('Math')
INSERT INTO Department VALUES('Sciology')
INSERT INTO Department VALUES('ICT')
INSERT INTO Department VALUES('Physics')
INSERT INTO Department VALUES('Camestry')
INSERT INTO Department VALUES('IslamicHistory')
INSERT INTO Department VALUES('Economics')
INSERT INTO Department VALUES('Zology')
INSERT INTO Department VALUES('Butany')
INSERT INTO Department VALUES('Accaunting')
INSERT INTO Department VALUES('Manesment')
INSERT INTO Department VALUES('Philosophy')
go



--INSERT DATA TO Staff TABLE

INSERT INTO Staff VALUES 
(1,'Manejer',4000.00),
(2,'pion',3000.00),
(3,'Helper',2000.00),
(4,'Pion',5000.00),
(5,'Driver',6000.00),
(6,'Director',7000.00)
go


--INSERT DATA TO  TABLE Student

INSERT INTO Student VALUES
('Kamal Hossain'),
('Abul Hossain'),
('Josna Akter'),
('Rupa Akter'),
('Jamal Hossain'),
('Ashraf Ali'),
('Liton Mia'),
('Nur Alom')
go


--INSERT DATA TO  TABLE gender

INSERT INTO gender VALUES
('Male'),
('Female')
GO

--INSERT DATA TO  TABLE Teachers

  INSERT INTO Teachers VALUES

  ('Mahmud','Sabuj',1,'11-19-1995','01912119319','hello@mahmudsabuj.com','Panthopoth, green road',1205,'Dhaka','Bangladesh'),
  ('Sharif','Mahmud',2,'04-14-1992','01912119348','sharif@gmail.com','Agargaon',1207,'Dhaka','Bangladesh'),
  ('Aman','Ullah',3,'01-23-1990','01912119316','aman@yahoo.com','Boddo mondir, Basabo',1212,'Dhaka','Bangladesh'),
  ('Rabeya','Khatun',4,'12-17-1981','01912119311','khala@ymail.com','Mohammod pur',1210,'Dhaka','Bangladesh'),
  ('kona','Khatun',5,'12-17-1981','01912119322','konla@ymail.com','Jatrabari',1217,'Dhaka','Bangladesh'),
  ('Anas','Ahmed',6,'11-19-1995','01912119319','anas@mahmudsabuj.com','Laksam, monohorgong',2505,'Comilla','Bangladesh'),
  ('Mohammod','Akas',7,'04-14-1882','01912139348','mohamed@gmail.com','Firojpur',3007,'Borisal','Bangladesh'),
  ('Murad','Ullah',8,'01-23-1980','01912519316','Murad@yahoo.com','lokkhipur,noakhali ',1212,'Noakhali','Bangladesh'),
  ('Hamid','khan',9,'12-27-1981','01912219311','Hamid@ymail.com','gulistha',1222,'Dhaka','Bangladesh'),
  ('Abul','Khatun',10,'12-37-1981','01919119322','abula@ymail.com','MIrpur',1219,'Dhaka','Bangladesh')
  GO

  --INSERT DATA TO  TABLE EXAM_result

  INSERT INTO EXAM_result VALUES
  (1,'test exam',1,2,'BANGLA','10-11-2020',70),
  (2,'Model test exam',2,1,'ENGLISH','11-11-2020',80),
  (3,'incouse exam',3,1,'MATH','12-11-2020',90),
  (4,'Midterm exam',1,3,'HISTORY','13-11-2020',50),
  (5,'final exam',5,8,'CAMESTRY','14-11-2020',80),
  (6,'classtest exam',1,1,'PHISICS','15-11-2020',20),
  (7,'ssc exam',7,1,'ICT','16-11-2020',70),
  (8,'Hsc exam',1,4,'STATICS','17-11-2020',65),
  (9,'honers exam',1,6,'ISLAM','18-11-2020',75),
  (10,'masters exam',6,1,'PHILOSOFY','19-11-2020',35),
  (11,'min exam',1,9,'SCIOLOGY','20-11-2020',36),
  (12,'semister exam',2,1,'POLITICAL SIENCE','21-11-2020',66),
  (13,'fstsem exam',4,1,'PUBLIC','22-11-2020',40),
  (14,'secnd sem exam',3,1,'LLB','23-11-2020',90),
  (15,'month test exam',9,1,'BBA','24-11-2020',50),
  (16,'test exam',1,1,'ACCAUNTING','25-11-2020',75),
  (17,'yeat exam',3,1,'MANEJMENT','26-11-2020',45)
  GO



  --SOME DATA ENTRY

--INSERT INTO Staff TABLE

EXEC sp_insertStaff 1,'Manager',50000
EXEC sp_insertStaff 2,'Assistant Manager',40000
EXEC sp_insertStaff 2,'Trainee Programmer',20000
EXEC sp_insertStaff 1,'Cleaner',10000
EXEC sp_insertStaff 3,'Driver',10000
GO

--INSERT INTO EXAM Table

EXEC sp_insertEXAM 'Incorse Exam'
EXEC sp_insertEXAM '1st year final'
EXEC sp_insertEXAM 'test exam'
EXEC sp_insertEXAM 'model_test Exam'
GO

--INSERT table Teachers

EXEC sp_insertTeachers 'Sumon','Ahmed','2345678765439',1,'11-19-1990','01912669319','hello@mahmusuabuj.com','Panthopoth, green road',1208,'Noakhali','Bangladesh'
EXEC sp_insertTeachers 'Alamin','Khan','2345678456095',2,'04-14-1989','01923119348','alamin@gmail.com','Agargaon',1201,'Dhaka','Bangladesh'
EXEC sp_insertTeachers 'Aman','Mia','2345678775875',3,'01-23-1998','01913219316','aman@yahoo.com','Boddo mondir, Basabo',1204,'Borisal','Bangladesh'
EXEC sp_insertTeachers 'Rima','Khatun','234548765099',4,'12-17-1979','01912999311','rimala@ymail.com','Mohammod pur',1224,'Chitogong','Bangladesh'
EXEC sp_insertTeachers 'Sumon','Ahmed','2345678765439',5,'11-19-1990','01912669319','hello@mahmusuabuj.com','Panthopoth, green road',1208,'Noakhali','Bangladesh'
EXEC sp_insertTeachers 'Alamin','Khan','2345678456095',6,'04-14-1989','01923119348','alamin@gmail.com','Agargaon',1201,'Dhaka','Bangladesh'
EXEC sp_insertTeachers 'Aman','Mia','2345678775875',7,'01-23-1998','01913219316','aman@yahoo.com','Boddo mondir, Basabo',1204,'Borisal','Bangladesh'
EXEC sp_insertTeachers 'Rima','Khatun','234548765099',8,'12-17-1979','01912999325','rimala@ymail.com','Mohammod pur',1224,'Chitogong','Bangladesh'
EXEC sp_insertTeachers 'Jafor','Mia','2345678765306',9,'11-19-1990','01912669220','jafor@mahmusuabuj.com','Panthopoth, green road',1208,'Noakhali','Bangladesh'
EXEC sp_insertTeachers 'Muhin','Uddin','2345678456420',10,'04-14-1980','01923119238','muhin@gmail.com','Agargaon',1201,'Dhaka','Bangladesh'
EXEC sp_insertTeachers 'Ripon','Mia','2345678775336',11,'01-23-1970','01913219560','ripon@yahoo.com','Boddo mondir, Basabo',1204,'Borisal','Bangladesh'
EXEC sp_insertTeachers 'Razia','Khatun','234548765208',12,'12-17-1975','01912999610','razia@ymail.com','Mohammod pur',1224,'Chitogong','Bangladesh'
EXEC sp_insertTeachers 'Suhan','Molla','2345678765570',13,'11-19-1991','01912669658','suhan@mahmusuabuj.com','Panthopoth, green road',1208,'Noakhali','Bangladesh'
EXEC sp_insertTeachers 'Maksud','Khan','2345678456780',14,'04-14-1982','01923119312','maksud@gmail.com','Agargaon',1201,'Dhaka','Bangladesh'
EXEC sp_insertTeachers 'Mujammel','Mia','2345678775197',15,'01-23-1996','01913219632','mujammelyahoo.com','Boddo mondir, Basabo',1204,'Borisal','Bangladesh'
EXEC sp_insertTeachers 'Sabina','Khatun','234548765236',16,'12-17-1974','01912999791','sabina@ymail.com','Mohammod pur',1224,'Chitogong','Bangladesh'
GO

--INSERT INTO Student

EXEC sp_insertStudent 1,'Jamal Khan'
EXEC sp_insertStudent 2,'Kamal Khan'
EXEC sp_insertStudent 3,'Sujon Mahmud'
EXEC sp_insertStudent 4,'Al-amin'
GO

--INSERT INTO EMPLOYEE Exam

EXEC sp_insert_EXAM 1,1,'Jamal Khan',1,'12/15/2020'
EXEC sp_insert_EXAM 1,1,'Kamal Khan',1,'12/15/2020'
EXEC sp_insert_EXAM 1,1,'Sujon Mahmud',1,'12/15/2020'
EXEC sp_insert_EXAM 1,1,'Al-amin',1,'12/15/2020'

GO

--INSERT INTO Staff TABLE

EXEC  sp_inserStaff 1,'college Management',50000
EXEC  sp_inserStaff 2,'sicurity gard',50000
EXEC  sp_inserStaff 3,'Driver',50000
EXEC  sp_inserStaff 4,'Helper',50000
EXEC  sp_inserStaff 5,'Dipertment Gard',50000
EXEC  sp_inserStaff 6,'Cheking Boy',50000
EXEC  sp_inserStaff 7,'Pion',50000
EXEC  sp_inserStaff 8,'Superviser',50000
go

--> TABLE DETAILS
EXEC sp_help Teachers
GO

--> INDEX DETAILS
EXEC sp_helpindex studenatendnes
GO

--> CONSTRAINT DETAILS
EXEC sp_helpconstraint EXAM_result
GO

--> DATABASE INFORMATION
EXEC sp_helpdb EducationSystem_Nu
GO

--> TESTING VIEW
--> Dhaka wise teachers

SELECT * FROM vDhakateachers
GO

--> TESTING FUNCTION fn_TeacheratendnessBasedbonus
--> --CALCULATE Teachers Salary AND Bonus

SELECT * FROM fn_TeacheratendnessBasedbonus
GO

--------Select quary for Dhaka address wise teachers


SELECT TeachersID,firstName,lastName,genderID,email,streetAddress,
postalCode,city,country FROM Teachers
where city='Dhaka'
Order by city
GO


--Quary with Aggregate use without Grouping


SELECT count(c.StudentID) TotalID,sum(c.roomID) AS 'Total Fine' FROM Teachers t
INNER JOIN Department d On d.departmentID=t.TeachersID
JOIN Staff s  ON t.TeachersID=d.departmentName
JOIN Classroom c ON t.firstName=s.StaffID
GO


--SUBQUARY FOR Salary CALCUALTING From who got 3000 tk salary


SELECT s.StaffID,s.StaffTitle,s.StaffTitle FROM Staff s
WHERE s.salaryAmount<(SELECT DISTINCT salaryAmount FROM Staff WHERE salaryAmount=3000)
ORDER BY StaffID ASC
go


--Quary of Staff salary Table(Show one staff total salary)


SELECT Count(*) AS StaffId,sum(salaryAmount) AS 'Total salary' FROM Staff
Where StaffID=3;
GO


--AGRAGIDE FUNCTION USE on all teacher and staff salary



SELECT  sum(s.salaryAmount) as [sum],
max (s.salaryAmount)as [max],
AVG(s.salaryAmount) as [AVG],
min(s.salaryAmount) as [min]
FROM Staff s
GO



--> JOIN QUERY 
--> DEPARTMENT WISE Teacher SALARY with total

SELECT t.firstName,d.departmentName,SUM(s.salaryAmount) Salary FROM Staff s
JOIN Teachers t ON s.StaffID=t.TeachersID
LEFT JOIN Department d ON s.StaffID=t.TeachersID
WHERE t.TeachersID IN(SELECT StaffID FROM Staff)
GROUP BY s.StaffID,t.firstName WITH ROLLUP
GO



--> SUB QUERY 
--> HAVING CLAUSE
--> WHO teact 3 OR MORE Subject He is a senior teachers in this College

SELECT t.TeachersID [ID],t.firstName [Name],t.email [Email],COUNT(d.departmentID) [Total subject] FROM Teachers t
JOIN Department d ON d.departmentID=t.TeachersID
JOIN Staff s  ON s.StaffID=t.TeachersID
WHERE MONTH(t.birthDate)=12 AND YEAR(t.birthDate)=1990 -->FOR DECEMBER 1990
GROUP BY t.TeachersID,t.firstName,t.email
HAVING COUNT(t.firstName) >=3
GO


--> CTE - Teachers

WITH CTE_Teachers (firstName,departmentName, salaryAmount)
AS
(
SELECT t.firstName,d.departmentName,SUM(s.salaryAmount) Salary FROM Teachers t
JOIN Department d ON d.departmentID=t.TeachersID
LEFT JOIN Staff s ON s.StaffID=d.departmentID
WHERE t.TeachersID IN(SELECT TeachersID FROM Teachers)
GROUP BY d.departmentName,t.firstName WITH ROLLUP
)
SELECT * FROM Teachers
GO




