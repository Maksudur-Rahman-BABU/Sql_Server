
                     -- SQL Project: Education System_Nu (National University) ------
                        --Project By: MAKSUDUR RAHMAN ------
                       --Batch ID: ESAD-CS/PNTL-M/49/01 ------
                           ----Trainee ID: 1266309 -----


--Creating Database and table

DROP DATABASE IF EXISTS EducationSystem_Nu
GO

CREATE DATABASE EducationSystem_Nu
ON
(
	NAME= 'EducationSystem_Nu_Data',
	FILENAME='D:\MidXm\Project_Data.mdf',
	SIZE=100MB,
	MAXSIZE=500MB,
	FILEGROWTH=5%
)
LOG ON
(
	NAME='EducationSystem_Nu_log',
	FILENAME='D:\MidXm\Project_log.ldf',
	SIZE=50MB,
	MAXSIZE=200MB,
	FILEGROWTH=5%
)
GO

USE EducationSystem_Nu
GO

CREATE TABLE Department
(
	departmentID INT IDENTITY PRIMARY KEY,
	departmentName VARCHAR(15) NOT NULL,
)
GO

CREATE TABLE Staff
(
	StaffID INT IDENTITY PRIMARY KEY,
	departmentID INT REFERENCES Department(departmentID),
	StaffTitle VARCHAR(20) NOT NULL,
	salaryAmount MONEY
)
GO

CREATE TABLE Student
(
	StudentID INT IDENTITY PRIMARY KEY,
	StudentName VARCHAR(15) NOT NULL
)
GO

CREATE TABLE gender
(
	genderID INT PRIMARY KEY IDENTITY,
	gender VARCHAR(6) NOT NULL
)
GO

CREATE TABLE Teachers
(
	TeachersID INT PRIMARY KEY IDENTITY(101,1),
	firstName VARCHAR(20) NOT NULL,
	lastName VARCHAR(20) NOT NULL,
	genderID INT REFERENCES gender(genderID) NOT NULL,
	birthDate DATETIME NOT NULL,
	contactNo VARCHAR(15) NOT NULL,
	email VARCHAR(70) NOT NULL,
	streetAddress VARCHAR(100) NOT NULL,
	postalCode INT NOT NULL,
	city VARCHAR(20) NOT NULL DEFAULT 'Dhaka',
	country VARCHAR(25) NOT NULL
)
GO

CREATE TABLE College 
(
collegeID int PRIMARY KEY,
collegeName VARCHAR(30)
)
GO
CREATE TABLE Classroom
(
roomID INT PRIMARY KEY,
TeacherId INT REFERENCES Teachers(TeachersID) NOT NULL,
StudentID INT REFERENCES Student(StudentID) NOT NULL
)
GO

CREATE TABLE EXAM
(
ExamID INT PRIMARY KEY,
ExamName VARCHAR(30),
StudentID INT REFERENCES Student(StudentID) NOT NULL,
TeacherId INT REFERENCES Teachers(TeachersID) NOT NULL,
[Subject] INT REFERENCES Department(departmentID) NOT NULL,
ExamDate date
)
go

Create TABLE StudentTeachersdetails
 (
 studentId int REFERENCES Student(StudentID),
 teacherId int REFERENCES Teachers(TeachersID),
 studentnId CHAR(13) UNIQUE NOT NULL CHECK(studentnId LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'), 
 teacherNid CHAR(13)
 )
 GO


CREATE TABLE EXAM_result
(
ExamID INT PRIMARY KEY,
ExamName VARCHAR(30),
StudentID INT REFERENCES Student(StudentID) NOT NULL,
TeacherId INT REFERENCES Teachers(TeachersID) NOT NULL,
[Subject] INT REFERENCES Department(departmentID) NOT NULL,
ExamDate date,
Marks VARCHAR(30)
)
go

CREATE TABLE Atendness
(
AtendDate date,
StudentAtend INT REFERENCES Student(StudentID) NOT NULL,
TeacherAtend INT REFERENCES Teachers(TeachersID) NOT NULL
)
go


------------------------- => ALTER TABLE EXAM_result <=-------------------

ALTER TABLE EXAM_result
ADD ExamName varchar(255)
GO


--Crete [ Clustered index ] ON Student adendness for studentattendneess table 

CREATE CLUSTERED INDEX studenatendnes   
    ON Atendness(studentAtend)
GO 


--Creating [ NON clustered index ] ON streetAddress for Teachers table

CREATE NONCLUSTERED INDEX streesADDRESS
ON Teachers(streetAddress)
GO


---VIEW for Dhaka address wise teachers 

create view vDhakateachers

as

SELECT TeachersID,firstName,lastName,genderID,email,streetAddress,
postalCode,city,country FROM Teachers
where city='Dhaka'
Order by city
GO


-- Create stored procedure for INSERTING data into Staff table


CREATE PROC sp_insertStaff
			@StafID INT,
			@stitle VARCHAR(20),
			@Samount MONEY
AS
BEGIN
	INSERT INTO Staff VALUES(@StafID,@stitle,@Samount)
END
GO


-- Create stored procedure for INSERTING data into EXAM table


CREATE PROC sp_insertEXAM
			@EXAMName VARCHAR(30)
AS
BEGIN
	INSERT INTO EXAM VALUES (@EXAMName)
END
GO

-- Create stored procedure for INSERTING data into Teachers table


CREATE PROC sp_insertTeachers
			@fname VARCHAR(20),
			@lname VARCHAR(20),
			@nid CHAR(13),
			@genderID INT,
			@dob DATETIME,
			@contactNo VARCHAR(15),
			@email VARCHAR(70),
			@streetAddress VARCHAR(100),
			@postalCode INT,
			@city VARCHAR(20),
			@country VARCHAR(25)
AS
BEGIN
	INSERT INTO Teachers VALUES(@fname,@lname,@nid,@genderID,@dob,@contactNo,@email,@streetAddress,@postalCode,@city,@country)
END
GO


-- Create stored procedure for INSERTING data into Student table

CREATE PROC sp_insertStudent
			@studentID INT,
			@StudentName VARCHAR(100)
AS
BEGIN
	INSERT INTO Student VALUES(@studentID,@StudentName)
END
GO

-- Create stored procedure for INSERTING data into EXAM table

CREATE PROC sp_insert_EXAM
			@examID INT,
			@studentID INT,
			@studentName VARCHAR(100),
			@teacherID INT,
			@examDate DATE
AS
BEGIN
	INSERT INTO EXAM VALUES(@examID,@studentID,@studentName,@teacherID,@examDate)
END
GO



--Create stored procedure for UPDATING Staff and teacher salary
--Add 10% bonus if departmnt id >2

CREATE PROC sp_Staffsalary10persentdiscount
			@staffID INT
AS
BEGIN
Select salaryAmount'basic salary', StaffID
CASE 
		WHEN departmentID>2 THEN 0
		ELSE (salaryAmount*10/100)
	END Extra,
	CASE
		WHEN departmentID>5 THEN salaryAmount
		ELSE (salaryAmount*110/100)
	END SalaryAmonut

from (SELECT t.firstName+t.lastName EmployeeName,s.salaryAmount FROM Teachers t
JOIN Staff s ON s.departmentID=t.TeachersID
LEFT JOIN Department d ON d.departmentID=t.TeachersID
where t.TeachersID=@staffID)
go

-- Create stored procedure for INSERTING data into Staff table


CREATE PROC sp_inserStaff
			@StaffID INT,
			@StaffTitle VARCHAR,
			@StaffSalary MONEY
			
AS
BEGIN
	INSERT INTO Staff VALUES(@StaffID,@StaffTitle,@StaffSalary)
END
GO

--Create stored procedure for INSERTING data into EXAM_result table

CREATE PROC sp_EXAM_result
			@examID INT,
			@studentID INT,
			@examdate DATE
AS
BEGIN
	INSERT INTO EXAM_result VALUES(@examID,@studentID,@examdate)
END
GO

-- Create stored procedure for DELETING data from Staff table


CREATE PROC sp_deleteStaff
			@id INT
AS
BEGIN
	DELETE FROM Staff
	WHERE StaffID=@id
END
GO

-- Create stored procedure for DELETING data from Teachers table

CREATE PROC sp_Teachers
			@TeachersID INT
AS
BEGIN
	DELETE FROM Teachers WHERE TeachersID=@TeachersID
END
GO


---Create stored procedure for DELETE data from sp_Teachers table

CREATE PROC sp_deleteTeachers
			@TeachersID INT
AS
BEGIN
	DELETE FROM Teachers
	WHERE TeachersID=@TeachersID
END
GO


-- Create stored procedure for DELETING data from Department table

CREATE PROC sp_deleteDepartment
			@departmentID INT
AS
BEGIN
	DELETE FROM Department WHERE departmentID=@departmentID 
END
GO


-- Create TRIGGER for tbl_Student Not modification 

CREATE TRIGGER tr_LockStudentTableMofication
	ON Student
	FOR INSERT,UPDATE,DELETE
AS
	PRINT 'You cannot modify a table!'
	ROLLBACK TRANSACTION
GO



-- Create TRIGGER for preventing gender from modification


CREATE TRIGGER tr_lockGenderMofication
	ON gender
	FOR INSERT,UPDATE,DELETE
AS
	PRINT 'You Can Not Modify or Delete GENDER!'
	ROLLBACK TRANSACTION
GO


--TEST


EXEC  sp_insertEXAM 'In-cours EXAM'
EXEC sp_insertEXAM 'Semister Final exam'
GO


--Create TRIGGER for preventing data DELETE & Update from EXAM table

CREATE TRIGGER tr_examUpdateDelete
	ON EXAM
	FOR UPDATE,DELETE
AS
	PRINT 'You can nott update or delete EXAM table!'
	ROLLBACK TRANSACTION
GO


--CREATE TRIGGER FOR AUTOMATIC UPDATE Classroom
--SET teacherID TO 'ON-HOLD' IF CLASSROOM INFORMATION UPDATED FROM ATENDNES
CREATE TRIGGER tr_updateClassroomOnEmpModification
    ON Classroom
    AFTER UPDATE
	AS
    BEGIN
	DECLARE @roomID INT;
		SELECT @roomID=TeacherId FROM inserted
		UPDATE Classroom
		SET TeacherId=3
		WHERE TeacherId=@roomID
    END
GO

--CREATE TRIGGER PREVENT DELETE FOR College

CREATE TRIGGER tr_priventDeleteYearlyLeave
ON College
FOR DELETE
AS
BEGIN
 ROLLBACK TRANSACTION
 PRINT 'sorry! You can not enter College'
END
GO

--FUNCTION
--CALCULATE Teachers Salary AND Bonus
--BASED ON Staff COMPLETE
-------Teacher atendnes less than or equal 1 => add bonus 0.00
-------Teacher Atennes more than or equal 2 and less than 3 => add bonus 10%
-------Teacher Atennes more than or equal 5 => add bonus 15%


CREATE FUNCTION fn_TeacheratendnessBasedbonus
(
	@TeacherId INT,
	@atendness Date
)
RETURNS TABLE
AS
RETURN
(
	select StaffID,salaryAmount 'Basic Salary',Atendness,
	CASE
		WHEN TotalAtend<=1 THEN 0
		WHEN TotalAtend>=2 AND TotalAtend<5 THEN (salaryAmount*10/100)
		WHEN TotalAtend>=5 THEN (salaryAmount*15/100)
	END Bonus,
	CASE
		WHEN TotalAtend<=1 THEN 0
		WHEN TotalAtend>=2 THEN (salaryAmount*110/100)
		WHEN TotalAtend>=5 THEN (salaryAmount*115/100)
	END salaryAmonut
	from (SELECT t.firstName+t.lastName s.salaryAmount,COUNT(*) TotalTeacher FROM Teachers
	JOIN Teachers t ON s.StaffID=t.TeachersID
	JOIN Atendness at ON t.TeachersID=[at].AtendDate
	JOIN Staff s ON s.StaffID=[at].TeacherAtend
	WHERE MONTH([at].AtendDate) IN(@month) AND YEAR([at].AtendDate) IN(@year)
	GROUP BY t.firstName+t.lastName,s.salaryAmount) vtable	
)
GO

-- INSTEAD OF TRIGGER
-- PREVENT ASSIGING Teachers
-- CAN'T ASSIGN MORE THAN 3 Name of teachers

CREATE TRIGGER tr_exrathreeteachers
ON Teachers
INSTEAD OF INSERT
AS
BEGIN
	DECLARE @fname VARCHAR(20),@lname VARCHAR(20), @nid CHAR(13),@country
	SELECT  @fname=firstName,@lname=lastName,@nid=genderID FROM inserted
	SELECT COUNT(TeachersId) FROM Teachers
	WHERE firstName=@fname 
	IF @count<3
		begin
			insert into Teachers
			select TeachersID,firstName,lastName from inserted
		end
	ELSE
		BEGIN
			RAISERROR('There are no teachers in this college')
		END
END
GO


























